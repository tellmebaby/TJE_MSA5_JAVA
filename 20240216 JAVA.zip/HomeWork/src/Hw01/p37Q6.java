package Hw01;

/**
 * 두번째 자바 프로그램을 만들어 보세요. 이글립스에서 'Hell, Java'대신 여러분의 이름을 출력해 보세요.
 */

public class p37Q6 {

	public static void main(String[] args) {
		
		System.out.println("홍성");
	}
}
