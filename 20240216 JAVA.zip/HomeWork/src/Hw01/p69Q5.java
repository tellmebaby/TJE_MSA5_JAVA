package Hw01;

public class p69Q5 {

	public static void main(String[] args) {
		
		char g = '\uae00';
		System.out.println(g);
	}
}
