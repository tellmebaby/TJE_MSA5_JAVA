package Day01;



public class Ex01_Print {

	// main : ctlr + space
	// 프로그램의 시작이 되는 메소드
	public static void main(String[] args) {
		//기본 출력문
		// - print(), println() 메소드를 호출하여 출력한다.
		// - System.out 출력 객체를 사용한다.
		// sysout : ctrl + space
		System.out.print("안녕하세요");
		
		// println();    -ln(line)
		// : 지정한 문자열을 출력 후, 한 줄 엔터
		System.out.println("안녕하세요 출력 후 줄바꿈");
		
		System.out.println("자바 첫 수업");
		System.out.println();
		System.out.println("이어지는 문자열...");
		System.out.println();
		System.out.println("第一의兒孩가무섭다고그리오.");
		System.out.println("第二의兒孩가무섭다고그리오.");
		System.out.println("第三의兒孩가무섭다고그리오.");
		System.out.println("第四의兒孩가무섭다고그리오.");
		System.out.println("第五의兒孩가무섭다고그리오.");
		System.out.println("第六의兒孩가무섭다고그리오.");
		System.out.println("第七의兒孩가무섭다고그리오.");
		System.out.println("第八의兒孩가무섭다고그리오.");
		System.out.println("第九의兒孩가무섭다고그리오.");
	}
}
