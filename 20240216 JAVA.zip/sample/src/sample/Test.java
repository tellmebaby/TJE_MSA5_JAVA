package sample;

public class Test {
	
	// main - ctrl + space
	// 프로그램의 시작!
	public static void main(String[] args) {
		// sysout - ctrl + space
		System.out.println("1의 아해가 1이라고 했다");
		System.out.println("2의 아해가 2이라고 했다");
		System.out.println("3의 아해가 3이라고 했다");
		// ctrl + S : 저장
		// ctrl + F11 : 프로그램 실행
	}
}
